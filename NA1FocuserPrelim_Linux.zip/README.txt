This zipped file contains files necessary to run the
main file 'NA1Focuser.py'

Included is a module, 'tempConverter.py' and it's associated
GUI file, 'TemperatureConverterGUI.py'

There is a shell PDF file that will be completed once all
the other programming is complete, but for now this allows
the use of the 'Help' menu as a stub.

All the files contained in this zipped file need to be
placed into the same directory.

"Your milage WILL vary!"

Tom