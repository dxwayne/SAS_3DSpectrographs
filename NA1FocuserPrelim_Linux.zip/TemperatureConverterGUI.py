#!/usr/bin/python3.7
#####################################################################
#   TemperatureConverterGUI.py                                      #
#####################################################################
#   Created by: Thomas C. Smith                                     #
#           on: 20210102                                            #
#####################################################################
#   Revisions                                                       #
#   - 20210102 - Initial development                                #
#####################################################################
#   Notes                                                           #
#   - This program uses a list array to determine which method to   #
#       call from the imported module 'tempConverter'.              #
#####################################################################

#####################################################################
#   Libraries and Modules to import                                 #
#####################################################################
import  tkinter as tk
from    tkinter import ttk
from    tempConverter import *
#####################################################################
#   End of Libraries and Module imports                             #
#####################################################################

#####################################################################
#   Variables                                                       #
#####################################################################
theList = ['Celsius','Fahrenheit','Kelvin','Rankine','Delisle','Newton','Reaumur','R0mer']
t = tempConv()
mArray = []
w = 0
# insert the array of 7x8 function calls as strings
# TO = X, FROM = Y
arrCelsius      = ['n/a','c2f','c2k','c2r','c2d','c2n','c2re','c2r0']
arrFahrenheit   = ['f2c','n/a','f2k','f2r','f2d','f2n','f2re','f2r0']
arrKelvin       = ['k2c','k2f','n/a','k2r','k2d','k2n','k2re','k2r0']
arrRankine      = ['r2c','r2f','r2k','n/a','r2d','r2n','r2re','r2r0']
arrDelisle      = ['d2c','d2f','d2k','d2r','n/a','d2n','d2re','d2r0']
arrNewton       = ['n2c','n2f','n2k','n2r','n2d,','n/a','nre','n2r0']
arrReaumur      = ['re2c','re2f','re2k','re2r','re2d','re2n','n/a','re2r0']
arrR0mer        = ['r02c','r02f','r02k','r02r','r02d','r02n','r0re','n/a']
#####################################################################
#   End of Variables                                                #
#####################################################################
# Real array so x = from and y = to
##c2f f2c k2c r2c d2c n2c re2c r02c 
##c2k f2k k2f r2f d2f n2f re2f r02f 
##c2r f2r k2r r2k d2k n2k re2k r02k 
##c2d f2d k2d r2d d2r n2r re2r r02r 
##c2n f2n k2n r2n d2n n2d, re2d r02d 
##c2re f2re k2re r2re d2re nre re2n r02n 
##c2r0 f2r0 k2r0 r2r0 d2r0 n2r0 re2r0 r0re 

# now populate the mArray from the 8 temperature arrays
mArray.append(arrCelsius)
mArray.append(arrFahrenheit)
mArray.append(arrKelvin)
mArray.append(arrRankine)
mArray.append(arrDelisle)
mArray.append(arrNewton)
mArray.append(arrReaumur)
mArray.append(arrR0mer)

#print(mArray)

def convert(event):
    """
    This function is used to run the binding event of pressing
    the 'RETURN' key.
    """
    doConvert()

def doConvert():
    """
    This method reads the variables of FROM and TO and
    call the appropriate tempConverter method
    """
    # read the comboboxes and the WHAT.get() then do the conversion
    w = WHAT.get()
    if w == 0:
        RESULT.set("Invalid")
    theFrom = cbxFrom.current()
    theTo = cbxTo.current()
    UNIT.set(theList[theTo])
    FROM.set(theFrom)
    TO.set(theTo)
    if (theTo == theFrom):
        RESULT.set('Invalid')
        message.set("Can't convert to same units")
        return 0
    function = mArray[FROM.get()][TO.get()]
##    print('From:',FROM.get())
##    print('To:', TO.get())
##    print(function)
    ret = t.choose(function, w)
    RESULT.set(ret)
    
def doQuit():
    """
    Quits the program.
    """
    app.destroy()

def doClear():
    """
    Clears the fields for next useage.
    """
    TO.set('')
    FROM.set('')
    RESULT.set('')
    UNIT.set('')
    WHAT.set('')

def doCopy():
    """
    Copies the contents of the 'Result' field to the clipboard.
    """
    if (RESULT.get() == ''):
        message.set("Nothing to copy")
        return
    app.clipboard_clear()
    app.clipboard_append(RESULT.get())
    message.set("Result copied to the clipboard")

def clearMessage():
    message.set("")
    app.after(10000, clearMessage) # cycle running
#####################################################################
#   Define the GUI                                                  #
#####################################################################
app = tk.Tk()
app.title("Simple Temperature Converter")
app.config(background = "tan")

#   Define a Frame object within the main GUI (app)
frame = tk.Frame(app, background = "tan")
frame.grid(column = 0, row = 0)
#   Create tkinter variables
TO      = tk.IntVar()
FROM    = tk.IntVar()
RESULT  = tk.StringVar()
UNIT    = tk.StringVar()
WHAT    = tk.DoubleVar()

#   Populate some of the tkinter variables
WHAT.set(0.0)
instruct    = tk.StringVar()
message     = tk.StringVar()
instruct.set("Select conversions using the two combo boxes\nthen click 'Convert' or press '<RETURN>'")

#   The form controls
tk.Label(frame, textvariable = instruct, background = "black", foreground = "yellow").grid(column = 0, row = 0, columnspan = 4, sticky = ('e','w'))
# From area
tk.Label(frame, text = "From:", background = "tan").grid(column = 0, row = 1, sticky = ('e'))
cbxFrom = ttk.Combobox(frame, values = theList,width = 10)
cbxFrom.grid(column = 1, row = 1, sticky = ('w'))
# To area
tk.Label(frame, text = "To:", background = "tan").grid(column = 2, row = 1, sticky = ('e'))
cbxTo = ttk.Combobox(frame, values = theList, width = 10)
cbxTo.grid(column = 3, row = 1, sticky = ('w'))
# What value to convert
tk.Label(frame, text= "Value to convert:", background = "tan").grid(column = 0, row = 2, sticky = ('e'))
What = tk.Entry(frame, textvariable = WHAT, background = "lightgreen", width = 10)
What.grid(column = 1, row = 2, sticky = ('w'))
# The results area
tk.Label(frame, text = "Result:", background = "tan", width = 6).grid(column = 0, row = 3, sticky = ('e'))
Result = tk.Label(frame, textvariable = RESULT, background = "lightgreen", width = 10, anchor='w')
Result.grid(column = 1, row = 3, columnspan = 2, sticky = ('w'))
tk.Label(frame, textvariable = UNIT, width = 10).grid(column = 2, row = 3, sticky = ('w'))
# The message area
tk.Label(frame, text = "Message:", background = "black", foreground = "white").grid(column = 0, row = 4, sticky = ('e'))
tk.Label(frame, textvariable = message, background = "lightyellow", width = 30).grid(column = 1, row = 4, columnspan = 4, sticky = ('w'))
# The command buttons
# Quit
Quit = tk.Button(frame, text = "Quit", command = doQuit, width = 10)
Quit.grid(column = 0, row = 5, columnspan = 2, sticky = ('w'))

# Copy
Copy = tk.Button(frame, text = "Copy Result", command = doCopy)
Copy.grid(column = 2, row = 5, sticky = ('e'))

# Clear
Clear = tk.Button(frame, text = "Clear", width = 10, command = doClear)
Clear.grid(column = 1, row = 5, sticky = ('e'))

# Convert 
Convert = tk.Button(frame, text = "Convert", width = 10, command = doConvert)
Convert.grid(column = 3, row = 5, sticky = ('e'))

# Event bindings
app.bind('<Return>',convert)

# Full form and Frame padding
for child in app.winfo_children():child.grid_configure(padx=3, pady=3)
for child in frame.winfo_children():child.grid_configure(padx=3, pady=3)

# Start by clearing the message are to start the automatic running cycle
clearMessage()

# Create the actual GUI
app.mainloop()
