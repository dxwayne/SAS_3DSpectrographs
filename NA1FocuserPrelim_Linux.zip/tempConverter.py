#################################################################
# tempConverter.py                                              #
#   Created by: Thomas C. Smith                                 #
#           On: 20201230                                        #
#################################################################
##    Celsius Fahrenheit Kelvin  Rankine  Delisle  Newton  Réaumur  Rømer
##    500.00  932.00 	 773.15  1391.67  −600.00  165.00  400.00   270.00
##    490.00  914.00 	 763.15  1373.67  −585.00  161.70  392.00   264.75
##    480.00  896.00 	 753.15  1355.67  −570.00  158.40  384.00   259.50
##    470.00  878.00 	 743.15  1337.67  −555.00  155.10  376.00   254.25
##    460.00  860.00 	 733.15  1319.67  −540.00  151.80  368.00   249.00
##    450.00  842.00 	 723.15  1301.67  −525.00  148.50  360.00   243.75
##    440.00  824.00 	 713.15  1283.67  −510.00  145.20  352.00   238.50
##    430.00  806.00 	 703.15  1265.67  −495.00  141.90  344.00   233.25
##    420.00  788.00 	 693.15  1247.67  −480.00  138.60  336.00   228.00
##    410.00  770.00 	 683.15  1229.67  −465.00  135.30  328.00   222.75
##    400.00  752.00 	 673.15  1211.67  −450.00  132.00  320.00   217.50
##    390.00  734.00 	 663.15  1193.67  −435.00  128.70  312.00   212.25
##    380.00  716.00 	 653.15  1175.67  −420.00  125.40  304.00   207.00
##    370.00  698.00 	 643.15  1157.67  −405.00  122.10  296.00   201.75
##    360.00  680.00 	 633.15  1139.67  −390.00  118.80  288.00   196.50 
class tempConv():
    """
    This is a temperature conversion module.
    """
    def __init__(self):
        """
    __init__() startup method run on instantiation
    of a tempConv() object.
    """
        pass

            
    def c2f(self, cIN: float) -> float:
        """
    c2f converts a temperature (float) of Celsius to
    a temperature (float) of Fahrenheit.
    """
        fOUT = cIN * (9/5) +32
        fOUT = round(fOUT, 3)
        return fOUT

    def c2k(self, cIN: float) -> float:
        """
    c2k converts a temperature (float) of Celsius to\
    a temperature (float) of Kelvin.
    """
        kOUT = cIN + 273.15
        kOUT = round(kOUT, 3)
        return kOUT

    def c2r(self, cIN: float) -> float:
        """
    c2r converts a temperature (float) of Celsius to
    a temperature (float) of Rankine.
    """
        rOUT = (cIN + 273.15) * (9/5)
        rOUT = round(rOUT, 3)
        return rOUT

    def c2d(self, cIN: float) -> float:
        """
    c2d converts a temperature (float) of Celsius to
    a temperature (float) of Delisle.
    """
        dOUT = (100 - cIN) * (3/2)
        dOUT = round(dOUT, 3)
        return dOUT

    def c2n(self, cIN: float) -> float:
        """
    c2n converts a temperature (float) of Celsius to
    a temperature (float) of Newton.
    """
        nOUT = cIN * (33/100)
        nOUT = round(nOUT, 3)
        return nOUT

    def c2re(self, cIN: float) -> float:
        """
    c2re converts a temperature (float) of Celsius to
    a temperature (float) of Reaumur.
    """
        reOUT = cIN * (4/5)
        reOUT = round(reOUT, 3)
        return reOUT

    def c2r0(self, cIN: float) -> float:
        """
    c2r0 converts a temperature (float) in Celsius to
    a temperature (float) of R0mer.
    """
        r0OUT = cIN * (21/40) + 7.5
        r0OUT = round(r0OUT, 3)
        return r0OUT

    def f2c(self, fIN: float) -> float:
        """
    f2c converts a temperature (float) of Fahrenheit
    to a temperature (float) of Celsius.
    """
        cOUT = (fIN - 32) * 5/9
        cOUT = round(cOUT,3)
        return cOUT

    def f2k(self, fIN: float) -> float:
        """
    f2k converts a temperature (float) of Farhenheit to
    a temperature (float) of Kelvin.
    """
        kOUT = (5/9) * (fIN -32) + 273.15
        kOUT = round(kOUT, 3)
        return kOUT

    def f2r(self, fIN: float) -> float:
        """
    f2r converts a temperature (float) ot Farhenheit to
    a temperture (float) of Rankine.
    """
        rOUT = fIN + 459.67
        rOUT = round(rOUT, 3)
        return rOUT

    def f2d(self, fIN: float) -> float:
        """
    f2d converts a temperature (float) of Farhenheit to
    a temperature (float) of Delisle.
    """
        dOUT = (212 - fIN) * (5/6)
        dOUT = round(dOUT, 3)
        return dOUT
   
    def f2n(self, fIN: float) -> float:
        """
    f3d converts a temperature (float) of Farhenheit to
    a temperature (float) of Newton.
    """
        nOUT = (fIN - 32) * (11/60)
        nOUT = round(nOUT, 3)
        return nOUT

    def f2re(self, fIN: float) -> float:
        """
    f2re converts a temperature (float) in Fahrenheit to
    a temperature (float) in Reaumur
    """
        reOUT = (fIN - 32) * (4/9)
        reOUT = round(reOUT, 3)
        return reOUT

    def f2r0(self, fIN: float) -> float:
        """
    f2r0 converts a temperature (float) of Farhenheit to
    a temperature (float) of R0mer.
    """
        r0OUT = (fIN - 32) * (7/24) + 7.5
        r0OUT = round(r0OUT, 3)
        return r0OUT

    def k2c(self, kIN: float) -> float:
        """
    k2c converts a temperature (float) of Kelvin to
    a temperature (float) of Celsius.
    """
        cOUT = kIN -273.15
        cOUT = round(cOUT, 3)
        return cOUT

    def k2f(self, kIN: float) -> float:
        """
    k2f converts a temperature (float) of Kelvin to
    a temperature (float) of Farhenheit.
    """
        fOUT = (9/5) * (kIN -273.15) + 32
        fOUT = round(fOUT, 3)
        return fOUT
    
    def k2r(self, kIN: float) -> float:
        """
    k2r converts a temperature (float) in Kelvin to
    a temperature (float) of Rankine.
    """
        rOUT = kIN * (9/5)
        rOUT = round(rOUT, 3)
        return rOUT
    
    def k2d(self, kIN: float) -> float:
        """
    k2d converts a temperature (float) of Kelvin to
    a temperature (float) of Delisle.
    """
        dOUT = (373.15 - kIN) * (3/2)
        dOUT = round(dOUT, 3)
        return dOUT
    
    def k2n(self, kIN: float) -> float:
        """
    k2n converts a temperature (float) of Kelvin to
    a temperature of Newton.
    """
        nOUT = (kIN - 273.15) * (33/100)
        nOUT = round(nOUT, 3)
        return nOUT
    
    def k2re(self, kIN: float) -> float:
        """
    k2re converts a temperature (float) of Kelvin to
    a temperature (float) of Reaumur.
    """
        reOUT = (kIN - 273.15) * (4/5)
        reOUT = round(reOUT, 3)
        return reOUT
    
    def k2r0(self, kIN: float) -> float:
        """
    k2r0 converts a temperature (float) of Kelvin to
    a temperature (float) of R0mer.
    """
        r0OUT = (kIN - 273.15) * (21/40) + 7.5
        r0OUT = round(r0OUT, 3)
        return r0OUT

    def r2c(self, rIN: float) -> float:
        """
    r2c converts a temperature (float) of Rankine to
    a temperature (float) of Celsius.
    """
        cOUT = (rIN -491.67) * (5/9)
        cOUT = round(cOUT, 3)
        return cOUT
    
    def r2f(self, rIN: float) -> float:
        """
    r2f converts a temperature (float) of Rankine to
    a temperature (float) of Fahrenheit.
    """
        fOUT = rIN - 459.67
        fOUT = round(fOUT, 3)
        return fOUT

    def r2k(self, rIN: float) -> float:
        """
    r2k converts a temperature (float) of Rankine to
    a temperature (float) of Kelvin.
    """
        kOUT = rIN * (5/9)
        kOUT = round(kOUT, 3)
        return kOUT

    def r2d(self, rIN: float) -> float:
        """
    r2d converts a temperature (float) of Rankine to
    a temperature (float) of Delisle.
    """
        dOUT = (671.67 - rIN) * (5/6)
        dOUT = round(dOUT, 3)
        return dOUT

    def r2n(self, rIN: float) -> float:
        """
    r2n converts a temperature (float) of Rankine to
    a temperature (float) of Newton.
    """
        nOUT = (rIN - 491.67) * (11/60)
        nOUT = round(nOUT, 3)
        return nOUT

    def r2re(self, rIN: float) -> float:
        """
    r2re converts a temperature (float) of Rankine to
    a temperature (float) of Reaumur.
    """
        reOUT = (rIN - 491.67) * 4/9
        reOUT = round(reOUT, 3)
        return reOUT

    def r2r0(self, rIN: float) -> float:
        """
    r2r0 converts a temperature (float) of Rankinr to
    a temperature (float) of R0mer.
    """
        r0OUT = (rIN - 491.67) * (7/24) + 7.5
        r0OUT = round(r0OUT, 3)
        return r0OUT

    def d2c(self, dIN: float) -> float:
        """
    d2c converts a temperature (float) of Delisle to
    a temperature (float) of Celsius.
    """
        cOUT = 100 - dIN * (2/3)
        cOUT = round(cOUT, 3)
        return cOUT


    def d2f(self, dIN: float) -> float:
        """
    d2f converts a temperature (float) of Delisle to
    a temperature (float) of Farhenheit.
    """
        fOUT = 212 - dIN * (6/5)
        fOUT = round(fOUT, 3)
        return fOUT

    def d2k(self, dIN: float) -> float:
        """
    d2k converts a temperature (float) of Delisle to
    a temperature (float) of Kelvin.
    """
        kOUT = 373.15 - (dIN * (2/3))
        kOUT = round(kOUT, 3)
        return kOUT

    def d2r(self, dIN: float) -> float:
        """
    d2r convers a temperatue (float) of Delsile to
    a temperature (float) of Rankine.
    """
        rOUT = 671.67 - dIN * (6/5)
        rOUT = round(rOUT, 3)
        return rOUT

    def d2n(self, dIN: float) -> float:
        """
    d2n converts a temperature (float) of Delisle to
    a temperature of Newton.
    """
        nOUT = 33 - dIN * (11/50)
        nOUT = round(nOUT, 3)
        return nOUT

    def d2re(self, dIN: float) -> float:
        """
    d2re converst a temperature (float) of Delisle to
    a temperature (float) of Reaumur.
    """
        reOUT = 80 - dIN * (8/15)
        reOUT = round(reOUT, 3)
        return reOUT

    def d2r0(self, dIN: float) -> float:
        """
    d2r0 converts a temperature (float) of Delisle to
    a temperature (float) of R0mer.
    """
        r0OUT = 60 - dIN * (7/20)
        r0OUT = round(r0OUT, 3)
        return r0OUT

    def n2c(self, nIN: float) -> float:
        """
    n2c converts a temperature (float) of Newton to
    a temperature (float) of Celsius.
    """
        cOUT = nIN * (100/33)
        cOUT = round(cOUT, 3)
        return cOUT
    
    def n2f(self, nIN: float) -> float:
        """
    n2f converts a temperature (float) of Newton to
    a temperature (float) of Farhenheit.
    """
        fOUT = nIN * (60/11) + 32
        fOUT = round(fOUT, 3)
        return fOUT    

    def n2k(self, nIN: float) -> float:
        """
    n2k converts a temperature (float) of Newton to
    a temperature (float) of Kelvin.
    """
        kOUT = nIN * (100/33) + 273.15
        kOUT = round(kOUT, 3)
        return kOUT

    def n2r(self, nIN: float) -> float:
        """
    n2r converts a temperature (float) of Newton to
    a temperature (float) of Rankine.
    """
        rOUT = nIN * (60/11) + 32
        rOUT = round(rOUT, 3)
        return rOUT

    def n2d(self, nIN: float) -> float:
        """
    n2d converts a temperature (float) of Newton to
    a temperature (float) of Delisle.
    """
        dOUT = (33 - nIN) * (50/11)
        dOUT = round(dOUT, 3)
        return dOUT

    def n2re(self, nIN: float) -> float:
        """
    n2re converts a temperature (float) of Newton to
    a temperature (float) of Reaumur.
    """
        reOUT = nIN * (80/33)
        reOUT = round(reOUT, 3)
        return reOUT

    def n2r0(self, nIN: float) -> float:
        """
    n2r0 converts a temperature (float) of Newton to
    a temperature (float) of R0mer.
    """
        r0OUT = nIN * (35/22) + 7.5
        r0OUT = round(r0OUT, 3)
        return r0OUT

    def re2c(self, reIN: float) -> float:
        """
    re2c converts a temperature (float) of Reaumur to
    a temperature (float) of Celsius.
    """
        cOUT = reIN * (5/4)
        cOUT = round(cOUT, 3)
        return cOUT

    def re2f(self, reIN: float) -> float:
        """
    re2f converts a remperature (float) of Reaumur to
    a temperature (float) of Fahrenheit.
    """
        fOUT = reIN * (9/4) + 32
        fOUT = round(fOUT, 3)
        return fOUT

    def re2k(self, reIN: float) -> float:
        """
    re2k converts a temperature (float) of Reaumur to
    a temperature (float) of Kelvin.
    """
        kOUT = reIN * (5/4) + 273.15
        kOUT = round(kOUT, 3)
        return kOUT

    def re2r(self, reIN: float) -> float:
        """
    re2r converts a temperature (float) of Reaumur to
    a temperature (float) of Rankine.
    """
        rOUT = reIN * (9/4) + 491.67
        rOUT = round(rOUT, 3)
        return rOUT

    def re2d(self, reIN: float) -> float:
        """
    re2d converts a temperature (float) of Reaumur to
    a temperature (float) of Delisle.
    """
        dOUT = (80 - reIN) * (15/8)
        dOUT = round(dOUT, 3)
        return dOUT

    def re2n(self, reIN: float) -> float:
        """
    re2n converts a temperature (float) of Reaumur to
    a temperature (float) of Newton.
    """
        nOUT = reIN * (33/80)
        nOUT = round(nOUT, 3)
        return nOUT

    def re2r0(self, reIN: float) -> float:
        """
    re2r0 converts a temperature (float) of Reaumur to
    a temperature (float) of R0mer.
    """
        r0OUT = reIN * (21/32) + 7.5
        r0OUT = round(r0OUT, 3)
        return r0OUT
     
    def r02c(self, r0IN: float) -> float:
        """
    r02c converts a temperature (float) of R0mer to
    a temperature (float) of Celsius.
    """
        cOUT = (r0IN - 7.5) * (40/21)
        cOUT = round(cOUT, 3)
        return cOUT

    def r02f(self, r0IN: float) -> float:
        """
    r02f converts a temperature (float) in R0mer to
    a temperature (float) of Farhenheit.
    """
        fOUT = (r0IN - 7.5) * (24/7) + 32
        fOUT = round(fOUT, 3)
        return fOUT

    def r02k(self, r0IN: float) -> float:
        """
    r02k converts a temperature (float) of R0mer to
    a temperature (float) of Kelvin.
    """
        kOUT = (r0IN - 7.5) * (40/21) + 273.15
        kOUT = round (kOUT, 3)
        return kOUT

    def r02r(self, r0IN: float) -> float:
        """
    r02r converts a temperature (float) of R0mer to
    a temperature (float) of Rankine.
    """
        rOUT = (r0IN - 7.5) * (24/7) + 491.67
        rOUT = round(rOUT, 3)
        return rOUT

    def r02d(self, r0IN: float) -> float:
        """
    r02d converts a temperature (float) of R0mer to
    a temperature (float) of Delisle.
    """
        dOUT = (60 - r0IN) * (20/7)
        dOUT = round(dOUT, 3)
        return dOUT

    def r02n(self, r0IN: float) -> float:
        """
    r02n converts a temperature (float) of R0mer to
    a temperature (float) of Newton.
    """
        nOUT = (r0IN - 7.5) * (22/35)
        nOUT = round(nOUT, 3)
        return nOUT

    def r02re(self, r0IN: float) -> float:
        """
    r02re converts a temperature (float) of R0mer to
    a temperature (float) of Reaumur.
    """
        reOUT = (r0IN - 7.5) * (32/21)
        reOUT = round(reOUT, 3)
        return reOUT
    
    def choose(self,IN: str, val: float) -> float:
        """
    'choose' is used intenrally to determine which convert
    method to call.
    """
        A = ''
        if IN == 'c2f':
            A = self.c2f(val)
        elif IN == 'c2k':
            A = self.c2k(val)
        elif IN == 'c2r':
            A = self.c2r(val)
        elif IN == 'c2d':
            A = self.c2d(val)
        elif IN == 'c2n':
            A = self.c2n(val)
        elif IN == 'c2re':
            A = self.c2re(val)
        elif IN == 'c2r0':
            A = self.c2r0(val)
        elif IN == 'f2c':
            A = self.f2c(val)
        elif IN == 'f2k':
            A = self.f2k(val)
        elif IN == 'f2r':
            A = self.f2r(val)
        elif IN == 'f2d':
            A = self.f2d(val)
        elif IN == 'f2n':
            A = self.f2n(val)
        elif IN == 'f2re':
            A = self.f2re(val)
        elif IN == 'f2r0':
            A = self.f2r0(val)
        elif IN == 'k2c':
            A = self.k2c(val)
        elif IN == 'k2f':
            A = self.k2f(val)
        elif IN == 'k2r':
            A = self.k2r(val)
        elif IN == 'k2d':
            A = self.k2d(val)
        elif IN == 'k2n':
            A = self.k2n(val)
        elif IN == 'k2re':
            A = self.k2re(val)
        elif IN == 'k2r0':
            A = self.k2r0(val)
        elif IN == 'r2c':
            A = self.r2c(val)
        elif IN == 'r2f':
            A = self.r2f(val)
        elif IN == 'r2k':
            A = self.r2k(val)
        elif IN == 'r2d':
            A = self.r2d(val)
        elif IN == 'r2n':
            A = self.r2n(val)
        elif IN == 'r2re':
            A = self.r2re(val)
        elif IN == 'r2r0':
            A = self.k2r0(val)
        elif IN == 'd2c':
            A = self.d2c(val)
        elif IN == 'd2f':
            A = self.d2f(val)
        elif IN == 'd2k':
            A = self.d2k(val)
        elif IN == 'd2r':
            A = self.d2r(val)
        elif IN == 'd2n':
            A = self.d2n(val)
        elif IN == 'd2re':
            A = self.d2re(val)
        elif IN == 'd2r0':
            A = self.d2r0(val)
        elif IN == 'n2c':
            A = self.n2c(val)
        elif IN == 'n2f':
            A = self.n2f(val)
        elif IN == 'n2k':
            A = self.n2k(val)
        elif IN == 'n2r':
            A = self.n2r(val)
        elif IN == 'n2d':
            A = self.n2d(val)
        elif IN == 'n2re':
            A = self.n2re(val)
        elif IN == 'n2r0':
            A = self.n2r0(val)
        elif IN == 're2f':
            A = self.re2f(val)
        elif IN == 're2k':
            A = self.re2k(val)
        elif IN == 're2r':
            A = self.re2r(val)
        elif IN == 're2d':
            A = self.re2d(val)
        elif IN == 're2n':
            A = self.re2n(val)
        elif IN == 're2r0':
            A = self.re2r0(val)
        elif IN == 'r02c':
            A = self.r02c(val)
        elif IN == 'r02f':
            A = self.r02f(val)
        elif IN == 'r02k':
            A = self.r02k(val)
        elif IN == 'r02r':
            A = self.r02r(val)
        elif IN == 'r02d':
            A = self.r02d(val)
        elif IN == 'r02n':
            A = self.r02n(val)
        elif IN == 'r02re':
            A = self.r02re(val)
        return A

    
