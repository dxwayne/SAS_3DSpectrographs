This folder will be used to gather the various Arduino and Python programs that could 
be part of the NA1 spectrograph and more.

Structure:
Arduino folder containing the I.ino files
Python folder for storing the various Python3 programs and GUIs
