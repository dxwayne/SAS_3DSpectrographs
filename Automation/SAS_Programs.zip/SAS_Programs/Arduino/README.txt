This folder contains many sample and some fully functional applications of which many
have an associated Python3 program to use wiht the Arduino sketches.

Some examples need some additional fleshing out for complete usefulness but most
should run as is.


In additioan I have added the starting code for my new observatory control program.

Thomas C. Smith