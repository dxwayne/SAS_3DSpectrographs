#####################################################################
#                       configureTesting.py                         #
#####################################################################
#                    Written By: Thomas C. Smith                    #
#####################################################################

import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("Testing")

style = ttk.Style()
style.configure("redlabel",background='red')
style.configure('greenlabel',background='red')
style.configure('whitelabel',background='white')

mainframe = tk.Frame(root)
mainframe.grid(column=0, row=0)

labelVar = tk.StringVar()
labelVar.set('new')

def changeText():
    if  (labelVar.get() == 'new'):
        print('Into "new" on changeText()')
        label.config(background='red')
        labelVar.set("red")
        print('Leaving changeText() with labelVar = ' + labelVar.get())
        
    elif  (labelVar.get() == "red"):
        print('Into "red" on changeText()')
        label.config(background='green')
        labelVar.set("green")
        print('Leaving changeText() with labelVar = ' + labelVar.get())
        
    elif (labelVar.get()=='blue'):
        print('Into "blue" on changeText()')
        label.config(background='red')
        labelVar.set("red")
        print('Leaving changeText() with labelVar = ' + labelVar.get())
        
    else:
        print('Into default "else" on changeText()')
        label.config(background='blue')
        labelVar.set("blue")
        print('Leaving changeText() with labelVar = ' + labelVar.get())


label = tk.Label(mainframe,text="Testing", width=20)
label.grid(column=0,row=0, columnspan=2, sticky=('e','w'))

mybutton = tk.Button(mainframe,text="Change", width=20,command=changeText)
mybutton.grid(column=0,row=1)

root.mainloop()
