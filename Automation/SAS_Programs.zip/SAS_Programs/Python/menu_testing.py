# !/usr/bin/python3

#############################################################
#                    mebu_testing.py                        #
#############################################################
#                 Written By: Thomas C. Smith               #
#############################################################
from tkinter import *
def donothing():
   filewin = Toplevel(root)
   button = Button(filewin, text="Do nothing button")
   button.pack()
   
root = Tk()
menubar = Menu(root)
filemenu = Menu(menubar, tearoff = 0)
filemenu.add_command(label="New", command = donothing)
filemenu.add_command(label = "Open", command = donothing)
filemenu.add_command(label = "Save", command = donothing)
filemenu.add_command(label = "Save as...", command = donothing)
filemenu.add_command(label = "Close", command = donothing)

filemenu.add_separator()

filemenu.add_command(label = "Exit", command = root.quit)
menubar.add_cascade(label = "File", menu = filemenu)
graphicmenu = Menu(menubar, tearoff=0)
graphicmenu.add_command(label = "Undo", command = donothing)

graphicmenu.add_separator()

graphicmenu.add_command(label = "Cut", command = donothing)
graphicmenu.add_command(label = "Copy", command = donothing)
graphicmenu.add_command(label = "Paste", command = donothing)
graphicmenu.add_command(label = "Delete", command = donothing)
graphicmenu.add_command(label = "Select All", command = donothing)

menubar.add_cascade(label = "Graphs", menu = graphicmenu)
helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label = "Help Index", command = donothing)
helpmenu.add_command(label = "About...", command = donothing)
menubar.add_cascade(label = "Help", menu = helpmenu)

root.config(menu = menubar)
root.mainloop()
