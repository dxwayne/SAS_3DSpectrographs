#################################################################
#                           logger.py                           #
#################################################################
#                   Written By: Tomas C. Smith                  #
#################################################################

""" Simple Observatory Logging System:
    Usage:
    write(logfile, message) - This creates or appends the 'message'
                              to logfile
"""

import io
import os
import time
from shutil import copyfile

def writeLog(logfile, message):
    # Take the name of the log file and append the message
    theFile = io.open(logfile, "a+") # open for appending or reading and if
                                    # the file does not exist it creates it.
    theFile.write(message + "\n")
    theFile.close()

def readLog(logfile):
    # Read the entire file
    theFile = io.open(logfile, "r") # open just for reading
    lines = theFile.read()
    theFile.close()
    print(lines)
    return lines

def readLogLine(logfile):
    # Read all lines fron logfile
    theFile = io.open(logfile, "r")
    lines = theFile.read()
    theFile.close()
    return lines
    print(lines)

def deleteFile(logfile):
    # deletes the passed logfile
    os.remove(logfile)
    print("File " + logfile + " has been deleted...\n")

def renameFile(logfile, newName):
    # this function renames the logfile to newName
    os.rename(logfile,newName)
    print(logfile + " has been renamed to " + newName)

message = "This is a test"
logfile = "TestLog.txt"
writeLog(logfile, message)
readLog(logfile)
