#############################################################################
# 			    ComPortDropDown.py			            #
#############################################################################
#                       Written By: Thomas C. Smith                         #
#############################################################################
# This program presents a listing of all attached USB device ports	    #
# use in selecting the working port for this code.			    #
#############################################################################

import serial
import time
import serial.tools.list_ports
from tkinter import *
from tkinter import ttk
from matplotlib import pyplot as plt

# Gather the list of active serial (USB or COM) ports for the dropdown
thePorts = []
ports = list(serial.tools.list_ports.comports())
for p in ports:
    thePorts.append(p)
    
if (len(ports)) == 0:
    thePorts =["None"]
    
class Window(Frame):

    def __init__(self, master=None):
        Frame.__init__(self, master)               
        self.master = master

def showit(event):
    print(whichCom.get())
    
root = Tk()
app = Window(root)
root.title("COM Testing")
whichCom = StringVar()

Label(root,text="Available COM Ports:").grid(column=0, row=0, sticky=('ew'))
cb = ttk.Combobox(root,values=[thePorts], state="readonly",
                  textvariable = whichCom,width=25)
cb.grid(row=0,column=1)
cb.bind("<<ComboboxSelected>>",showit)

root.mainloop()
