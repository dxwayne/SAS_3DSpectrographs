#!/usr/bin/env python

# lowSpec2CalInjector.py
# Here are the commands that are being used on the Arduino
# stepperDriverInjector.ino

#   **************************************************
#   *            Serial Command Protocol             *
#   **************************************************
#   *  H = home the injector                         *
#   *  I = drive inward, CW from above motor shatf   *
#   *  O = drive outward, CCW from above motor shaft *
#   *  M = move the steps value sent in (+/-)xxxxx   *
#   *  S = slit lamp LED ON                          *
#   *  7 = slit lamp LED OFF                         *
#   *  C = cal lamp relay ON                         *
#   *  5 = cal lamp relay OFF                        *
#   *  F = flat lamp relay ON                        *
#   *  6 = flat lamp relay OFF                       *
#   *  R = change speed of motor                     *
#   *  T = test all three lamps                      *
#   *  Z = reset the zero point w/ homing            *
#   *  0 = (zero) get status of parameters           *
#   *  ? = brief help on commands                    *
#   *************************************************/
 
#################################################################################
#			    Support Libraries			    		#
#################################################################################			
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import serial.tools.list_ports
import time
import io
import serial

thePorts = []
ports = list(serial.tools.list_ports.comports())
for p in ports:
    thePorts.append(p)
    
if (len(ports)) == 0:
    thePorts =["None"]



#################################################################################
#				Functions		 			#
#################################################################################
def sendCommand():
    # we will send the command as ascii to the USB port so it can be operated
    # on by the Arduino sketch
    try:
        ser.port = whichCom.get()
        ser.bytesize = serial.EIGHTBITS #number of bits per bytes
        ser.parity = serial.PARITY_NONE #set parity check: no parity
        ser.stopbits = serial.STOPBITS_ONE #number of stop bits
        ser.baudrate = 9600
        #ser.xonxoff = 1
        ser.timeout = 1
        if (ser.isOpen() == False):
            print("Opening the port")
            ser.open()
            time.sleep(0.5)
        strMessages.set(whichCom.get() + "Port is open!")
        print("port is open")
        #ser.flushInput()
        #ser.flushOutput()
        ser.flush()
        strMessages.set("Sending: " + strCommand.get())
        temp = strCommand.get() + '\n'
        print("Sending command: " + strCommand.get())
        ser.write(temp.encode())
        #ser.write(strCommand.get())
        # now wait for the reply
        strIncomming = ser.readline()
        while strIncomming == "" : #True:
            strIncomming = ser.readline()
            if (strIncomming != ""):
                # something was returned so display it in the strMessages
                strMessages.set(strIncomming)
                # do other things
                closePort()
                strMessages.set("Port is closed!")
                break
                readReply()
            else:
                strMessages.set("Noting yet!")
            # reset the command string to empty
        #closePort()
        clearCommand()
    except Exception as e:
        print("Error: " + str(e) )
    #pass

def readReply():
    # read in the reply from the Arduino
    print("In to readReply()")
    pass

def openPort():
    # after using the port chooser, open the selected port
    thePortToUse = whichCom.get()
    #ser.port(whichCom.get())                # setting the serial port
    ser.port=thePortToUse
    ser.baudrate = 9600                     # setting the serial speed
    ser.flushInput()                        # empty the buffer to start
    ser.open()
    strMessages.set("Port " + whichCom.get() + " is OPEN!")
    # get the Arduino parameters
    getArduinoParameters()
    #pass

def closePort():
    # close the port
    ser.close()
    # make the buttons disabled as appropriate
    btnInsert.configure(state="disabled")
    btnRetract.configure(state="disabled")
    btnHome.configure(state="disabled")
    btnClosePort.configure(state="disabled")
    bolPortSelected = False

    strMessages.set("Port closed!")
    
def setMaxSteps():
    # set the maximum steps after runnng the 'jogInjector' function
    maxSteps.set(-16000)

def setStepValue():
    # evaluate and set the 'theSteps' StringVar
    print(intSteps.get())
    
def moveInjector():
    # the steps is the amount to move the injector shaft, testing for best alignment
    # the direction is (-) = IN  or (+) = OUT
    #print("Move Injector")
    if (theSteps.get() != 0):
        strMessages.set("No step to move has been set")
    try:    
        myValue = int(theSteps.get())
        if (abs(myValue) > 1000):
            strMessages.set("Too large of a step requested!")
        else:
            # send the jog value
            makeCommand("m" + str(myValue))
            strMessages.set("Sending M" + theSteps.get())
##            if (strCommand != ""):
##                strCommand = strCommand + ",m" + str(myValue)
##            else:
##                strCommand = strCommand + "m" + str(myValue)
            # now send it and wait for reply
            sendCommand()
        clearCommand()
    except:
        strMessages.set("Error, not a number!")

def getArduinoParameters():
    # query the LowSpec2 injector for necessary current parameters
    strMessages.set("Getting Arduino Parameters")
    pass
	
def insertInjector():
    # inserting the injector to maxSteps
    #print("Inserting Injector")
    strMessages.set("Inserting Injector!")
    btnInsert.configure(state="disabled")
    btnRetract.configure(state="normal")
    makeCommand("i")
##    if (strCommand != ""):
##        strCommand = strCommand + ",i"
##    else:
##        strCommand = "i"
    sendCommand()
    clearCommand()
    #pass
	
def retractInjector():
    # retract the injector
    #print("Retracting Injector")
    strMessages.set("Retracting Injector!")
    btnRetract.configure(state="disabled")
    btnInsert.configure(state="normal")
    makeCommand("r")
##    if (strCommand != ""):
##        strCommand = strCommand + ",r"
##    else:
##        strCommand = "r"
    sendCommand()
    clearCommand()
    #pass
	
def homeInjector():
    # HOME the injector and then get the currentStep status
    strMessages.set("Homing Injector Shaft!")
    # disable the other ijnector buttons until we get a return from the Arduino
    btnRetract.configure(state="disabled")
    btnInsert.configure(state="disabled")
    makeCommand('h')
##    if (strCommand != ""):
##        strCommand = strCommand + ",h"
##    else:
##        strCommand = "h"
    sendCommand
    clearCommand()
    #pass

def doSlitLamp():
    print(str(chkSlitValue.get()))
    if (chkSlitValue.get() == 1):
        # turn it ON
        makeCommand('s')
##        if (strCommand != ""):
##            strCommand = strCommand + ",s"
##        else:
##            strCommand = "s"
        sendCommand()
        strMessages.set("Slit Lamp ON!")
        clearCommand()

    else:
        makeCommand('7')
##        if (strCommand != ""):
##            strCommand = strCommand + ",9"
##        else:
##            strCommand = "7"
        sendCommand
        strMessages.set("Slit Lamp OFF!")
        clearCommand()

def doCalLamp():
    if chkCalValue.get() == 1:
        # turn it on
        makeCommand('c')
##        if (strCommand != ""):
##            strCommand = strCommand + "c"
##        else:
##            strCommand = "c"
        sendCommand()
        strMessages.set("Cal Lamp On!")
        clearCommand()
    else:
        makeCommand('5')
##        if (strCommand != ""):
##            strCommand = strCommand + "5"
##        else:
##            strCommand = "5"
        sendCommand()
        strMessages.set("Cal Lamp OFF!")
        clearCommand()
	
def doFlatLamp():
    if chkFlatValue.get() == 1:
        makeCommand('f')
##        if (strCommand != ""):
##            strCommand = strCommand + ",f"
##        else:
##            strCommand = "f"
        sendCommand()
        strMessages.set("Flat Lamp ON!")
        clearCommand()
    else:
        makeCommand('6')
##        if (strCommand != ""):
##            strCommand = strCommand + "6"
##        else:
##            strCommand = "6"
        sendCommand()
        strMessages.set("Flat Lamp OFF!")
        clearCommand()
	
def showChoosenPort(event):
    # once selected from the dropdown, show the port in the GUI
    #print(whichCom.get())
    # split out the parts and show just the beginning before first '-'
    try:
        thisPort = whichCom.get().split("{")    # first split to remove leading '{'
        whichCom.set(thisPort[1])
        thisPort = whichCom.get().split(" ")    # second split to get just the port name without white space
        whichCom.set(thisPort[0])
        strMessages.set("Port " + thisPort[0] + " selected!")
    except:
        strMessages.set("No Ports Found!")
        return
    
    # now enable the buttons as needed
    btnInsert.configure(state="normal")
    btnRetract.configure(state="normal")
    btnHome.configure(state="normal")
    btnClosePort.configure(state="normal")
    bolPortSelected = True

def makeCommand(command):
    # build the command
    if (strCommand.get() != ""):
        strCommand.set((strCommand.get()) + "," + command)
    else:
        strCommand.set(command)
    print("strCommand = " + strCommand.get())
    
def clearCommand():
    strCommand.set("")

def showHelp():
    # show the help PDF
    pass

def showAbout():
    # show the about form
    pass
def clearMessages():
    # clear the message area
    strMessages.set("")

def doQuit():
    # quit the app after closing the Port if open
    #strMessages.set("Closing down!")
    #print("Closing port")
    if (ser.isOpen):
        ser.close()
    #strMessages.set("Serial Port closed")
    #print(ser.name + " is closed")
    # now close the app
    app.destroy()

#################################################################################
#			Global Objects and Variables                            #
#################################################################################
command = ""
ser = serial.Serial()                   # create the serial object
bolPortSelected = False                 # port selected flag
#strCommand = ""                         # contains the aggregate of the commands issued
#################################################################################
#			    Main GUI Programming			    	#
#################################################################################
app = tk.Tk()
app.title("LowRes2 Calibration Injector")
app.background="lightgray"
app.configure(padx=10, pady=10)

# Tk variables
intSteps = tk.IntVar()			# step set from the jogInjector function
intCurrentStep = tk.IntVar()		# actual current step retuened from the Arduino
strMessages = tk.StringVar()		# returned info from Arduino
bolHomeFound = tk.BooleanVar()		# flag to indicate if HOME was found
whichCom = tk.StringVar()		# the port to use for this conversation
jogInjector = tk.IntVar()               # steps to move injector motor '-' = IN, '+' = OUT
chkSlitValue = tk.IntVar()              # stores 0 or 1 depending on if it is set or not
chkCalValue = tk.IntVar()               # stores 0 or 1 depending on if it is set or not
chkFlatValue = tk.IntVar()              # stores 0 or 1 depending on if it is set or not
theSteps = tk.StringVar()               # value used in jogging the injector shaft
maxSteps = tk.IntVar()                  # maxSteps as obtained from the Arduino
strCommand = tk.StringVar()             # command to send to Arduino

#################################################################################
#		End of variable declaration and beginning GUI	    		#
#################################################################################

#################################################################################
#                                   MENU                                        #
#################################################################################
# Menu for GUI
menubar = tk.Menu(app, background="yellow")
filemenu = tk.Menu(menubar, tearoff=0)

filemenu.add_command(label="Quit", command=doQuit)
menubar.add_cascade(label="File", menu=filemenu)
homemenu = tk.Menu(menubar, tearoff=0)

homemenu.add_cascade(label="Home Injector", command=homeInjector, state="disabled")
menubar.add_cascade(label="Homing", menu=homemenu)

helpmenu = tk.Menu(menubar, tearoff=0)
helpmenu.add_cascade(label="Program Help (PDF)", command=showHelp)
helpmenu.add_separator()
helpmenu.add_cascade(label="About", command=showAbout)
menubar.add_cascade(label="Help", menu=helpmenu)
app.configure(menu=menubar)

#################################################################################
#                               MAIN GUI                                        #
#################################################################################
# Program start
# select the desired serial port to use
portFrame = tk.Frame(app).grid(columnspan=3)
tk.Label(app, text="Serial Port Assignment", bg="tan", fg="black").grid(row=0, column=0, columnspan=3, sticky=('e','w'))
tk.Label(portFrame,text = "Available COM Ports:").grid(row = 1, column = 0, sticky = ('ew'))
cbxPorts = ttk.Combobox(portFrame,values = [thePorts], state = "readonly",
                  textvariable = whichCom, width = 35)
cbxPorts.grid(row = 1, column = 1, columnspan = 3, sticky = ('w'))
btnClosePort = tk.Button(app, text = "Close", command = closePort, width=10, state="disabled", fg='blue')
btnClosePort.grid(column = 2, row = 2, sticky=('e'))
tk.Label(portFrame, text = "Selected Port:").grid(row = 2, column = 0, sticky = ('e'))
usePort = tk.Label(portFrame, textvariable = whichCom)
usePort.grid(row = 2, column = 1, sticky = ('w'))

# begin creating the buttons and checkboxes
tk.Label(app, text="Injector Action Commands", bg="tan", fg="black").grid(row=3, column=0, columnspan=3, sticky=('e','w'))
btnFrame = tk.Frame(app, padx=4, pady=4).grid(columnspan=3)
btnInsert = tk.Button(btnFrame, text = "Insert", command = insertInjector, state = "disabled", width = 18, padx=4, pady=4)
btnInsert.grid(row = 4, column = 0, sticky=('e','w'))
btnRetract = tk.Button(btnFrame, text = "Retract", command = retractInjector, state = "disabled", width = 18, padx=4, pady=4)
btnRetract.grid(row = 4, column = 1, sticky = ('e','w'))
btnHome = tk.Button(btnFrame,text = "Home Injector", command = homeInjector, state = "disabled", width = 18, padx=4, pady=4)
btnHome.grid(row = 4, column = 2, sticky = ('e','w'))
# lamps
chkFrame = tk.Frame(app).grid(columnspan=3)
tk.Label(chkFrame,text="Lamp Control", bg="tan", fg="black").grid(row = 5, column = 0, columnspan = 3, sticky = ('e','w'))
chkSlitLamp = tk.Checkbutton(chkFrame,text = "Slit Lamp", variable = chkSlitValue, command = doSlitLamp)
chkSlitLamp.grid(row = 6, column = 0)
chkCalLamp = tk.Checkbutton(chkFrame,text = "Cal Lamp", variable = chkCalValue, command = doCalLamp)
chkCalLamp.grid(row = 6, column = 1)
chkFlatLamp = tk.Checkbutton(chkFrame,text = "Flat Lamp", variable = chkFlatValue, command = doFlatLamp)
chkFlatLamp.grid(row = 6, column = 2)

# jog mode
jogFrame = tk.Frame(app).grid(columnspan=3)
tk.Label(jogFrame, text = "Injector Jogging", bg="tan", fg="black").grid(row = 7, column = 0, columnspan = 3, sticky = ('e','w'))
tk.Label(jogFrame, text = "Jog Steps +1000 to -1000\n(-)=In, (+)=Out").grid(row = 8, column = 0, sticky = ('e'))
inputSteps = tk.Entry(jogFrame, textvariable = theSteps, width = 7, background="lightgray")
inputSteps.grid(row = 8, column = 1, sticky = ('w'))
btnJog = tk.Button(jogFrame, text = "Jog Injector", command=moveInjector, width=15)
btnJog.grid(row=8, column=2, sticky=('e'))

# the messages
tk.Label(app, text = "Messages", bg="tan", fg="black").grid(row = 9, column = 0, columnspan=3, sticky = ('e','w'))
tk.Button(app, text = "Click to clear Messages:", command=clearMessages, width = 18).grid(row = 10, column = 0, sticky = ('e'))
theMessages = tk.Label(app, textvariable = strMessages, bg="lightgreen").grid(row = 10, column = 1, columnspan = 1, sticky = ('e','w'))
btnQuit = tk.Button(app, text="Quit", command=doQuit, width=10, fg="red")
btnQuit.grid(row=10,column=2, sticky=('e'))
################################################################################
#                               Event Bindings                                 #
################################################################################

cbxPorts.bind("<<ComboboxSelected>>",showChoosenPort)

##for child in app.winfo_children():
##    print("app.winfo:" + str(child))
##    if (str(child) != "menu"):
##        child.grid_configure(padx=4, pady=4)
app.mainloop()				# starts the GUI displaying
