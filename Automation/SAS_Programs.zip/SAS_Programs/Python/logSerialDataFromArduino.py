#####################################################
#           logSerialDataFromArduino.py             #
#####################################################
#           Written By: Thomas C. Smith             #
#####################################################

import serial
import time
import csv
import datetime as dt
import sys

# Either change these next two lines or use the dropdown version to
# gather the USB port data

#ser = serial.Serial('/dev/ttyACM0')    # on Linux
ser = serial.Serial('COM20')             # on Windows
ser.flushInput()

theDate = ""
myDate = list(["",""])
def make_date():
    # This function is used to generate a data portion of the filename
    # for use in creating a daily data file.
    theDate = ""
    now = dt.datetime.now()
    strYear = str(now.year)
    month = now.month
    day = now.day
    hour = now.hour
    minute = now.minute
    second = now.second
    if (month < 10):
        strMonth = "0" + str(month)
    else:
        strMonth = str(month)

    if (day < 10):
        strDay = "0" + str(day)
    else:
        strDay = str(day)
    if (hour < 10):
        strHour = "0" + str(hour)
    else:
        strHour = str(hour)
    if (minute < 10):
        strMinute = "0" + str(minute)
    else:
        strMinute = str(minute)
    if (second < 10):
        strSecond = "0" + str(second)
    else:
        strSecond = str(second)
    theDate = strYear + strMonth + strDay
    theTime = strHour + strMinute + strSecond
    myDate[0] = theDate
    myDate[1] = theTime
    return myDate   # array of data

while True:
    try:
        theDate = ""
        ser_bytes = ser.readline()
        decoded_bytes = ser_bytes[0:len(ser_bytes)-2].decode("utf-8")
        myDate = make_date()
        print(myDate[0] + "-" + myDate[1] + "," + decoded_bytes)
        fName = myDate[0] + "TankData.csv"
        with open(fName,"a", newline="\n") as f:
            writer = csv.writer(f,delimiter=",")
            writer.writerow([myDate[0] + "-" + myDate[1] + "," + decoded_bytes])
            ser.flushInput()
    except:
        print(sys.exc_info())
        break

